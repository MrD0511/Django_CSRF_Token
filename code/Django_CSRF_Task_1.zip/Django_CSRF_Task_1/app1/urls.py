from django.urls import path
from .views import student_list, add_student_no_csrf

urlpatterns = [
    path("", student_list, name="student_list"),
    path("add_student/", add_student_no_csrf, name="add_student"),
]