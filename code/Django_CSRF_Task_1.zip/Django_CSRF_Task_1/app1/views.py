from django.shortcuts import render, redirect
from .models import Student
from django.core.paginator import Paginator
from django.db.models import Q
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def student_list(request):
    search_query = request.GET.get("q", "")

    students = Student.objects.all()

    if search_query:
        students = students.filter(
            Q(name__icontains=search_query) |
            Q(dept__icontains=search_query) |
            Q(city__icontains=search_query)

        )
    
    paginator = Paginator(students, 10)
    page_num = request.GET.get("page")
    page_obj = paginator.get_page(page_num)

    return render(request, "app1/students.html", {
        "page_obj": page_obj,
        "search_query": search_query
    })


@csrf_exempt
def add_student_no_csrf(request):
    if request.method == "POST":
        name = request.POST.get("name")
        dept = request.POST.get("dept")
        city = request.POST.get("city")

        Student.objects.create(name=name, dept=dept, city=city)
        return redirect('student_list')

    return render(request, "app1/add_student.html")
